#!/bin/sh
./gg -a ethash -o stratum+tcp://ethash.unmineable.com:3333 -u SHIB:0x42c736266fe4fa97cfaea1d3e35c85bd80840927.RigTwoV2#bl2b-lduj -p x -w PartTime --low-load 1
